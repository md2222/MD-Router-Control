#!/bin/bash


echo "Install MD Router Control 1.0.1"
echo "These files will be created:"
echo "/usr/local/bin/mdrctrl"
echo "/usr/local/share/mdrctrl/<data files>"
echo "/usr/share/applications/mdrctrl.desktop"
echo "/usr/share/pixmaps/mdrctrl.png"
echo ""

echo -n "continue? (y/n): "
 
read ans
 
if [ "$ans" = "y" ] 
then


mkdir -p -- "/usr/local/share/mdrctrl"
mkdir -p -- "/usr/local/share/mdrctrl/icons"
cp -- mdrctrl "/usr/local/bin/"
cp -- settings.ui "/usr/local/share/mdrctrl/"
cp -- icons/*.png "/usr/local/share/mdrctrl/icons/"
cp -- mdrctrl.desktop "/usr/share/applications/"
cp -- icons/mdrctrl.png "/usr/share/pixmaps/"


echo "done"
#read -p "Press [Enter] key to exit..."

else

echo "canceled"

fi


exit 0
